package modelo;

import java.util.Map;

public abstract class HamburguesaException {
	public Map <String, Tipo> mp;
	public String nuevo;
	
	
	public abstract void repetido( Map <String, Tipo> mp, String nuevo)throws Exception;
	
	
	
}
