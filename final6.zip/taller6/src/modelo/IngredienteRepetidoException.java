package modelo;

import java.util.Map;

public class IngredienteRepetidoException extends HamburguesaException{

	

	

	@Override
	public void repetido(Map<String, Tipo> mp, String nuevo) throws Exception {
		// TODO Auto-generated method stub
		
			if (mp.get(nuevo) != null) {
				throw new Exception ("El ingrediente " + nuevo + " esta repetido");
				
			}
	}
}


	
