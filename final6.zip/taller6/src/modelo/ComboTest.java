package modelo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controlador.Restaurante;
import controlador.carga;

class ComboTest {
	private Restaurante res;
	private Combo cual;
	@BeforeEach
	public void setUp() throws Exception {
		res = carga.Leer("data/combos.txt", "data/menu.txt", "data/ingredientes.txt");
		cual = res.pedidocombo(0);
	}
	@Test
	public void PrecioComboTest() {
		assertEquals(22050.0, res.darprecioscombo(cual), "Da el precio correcto del combo");	
	}

}
