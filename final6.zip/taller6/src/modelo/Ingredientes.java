package modelo;

public class Ingredientes extends Tipo {

	public Ingredientes(String nombre, Double precio) {
		super(nombre, precio);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getNombre() {
		// TODO Auto-generated method stub
		return this.nombre;
	}

	@Override
	public void setNombre(String nombre) {
		// TODO Auto-generated method stub
		this.setNombre(nombre);
	}

	@Override
	public Double getPrecio() {
		// TODO Auto-generated method stub
		return this.precio;
	}

	@Override
	public void setPrecio(Double precio) {
		// TODO Auto-generated method stub
		this.precio = precio;
	}
}

	



	
	
	

	

