package controlador;

import java.util.ArrayList;

import java.util.Map;

import modelo.Combo;
import modelo.Ingredientes;
import modelo.Menu;
import modelo.Pedidos;
import modelo.Tipo;



public class Restaurante {
	
	private ArrayList<Combo> combos;
	private ArrayList<Tipo> menu;
	private ArrayList<Tipo> ingredientes;
	private Map <Integer, Pedidos> pedidos;
	

	public Restaurante(Map<String, Combo> combos, Map<String, Tipo> menu2, Map<String, Tipo> ingredientes2, Map <Integer, Pedidos> pedidos)
	{
		this.combos = new ArrayList<Combo>(combos.values());
		this.menu = new ArrayList<Tipo>(menu2.values());
		this.ingredientes = new ArrayList<Tipo>(ingredientes2.values());
		this.pedidos = pedidos;
		
	}
	
	public ArrayList<Tipo> darmenu() {
		
		return menu;
	}
	public ArrayList<Tipo> daringredientes() {
		
		return ingredientes;
	}
	public ArrayList<Combo> darcombo() {
		
		return combos;
	}
	public Map <Integer, Pedidos> darpedidos() {
		
		return pedidos;
	}
	public Double darprecioscombo(Combo com) {
		double respuesta = 0;
		int pos =  0;
		boolean sigue = true;
		double desc = 0;
		String nomcombo = com.darNombre();
		String des = com.darDescuento();
		
		if (des.equals("10%")) {
			desc = 0.1;
		}
		else {
			desc = 0.07;
			
		}
		
		while ( sigue == true && combos.size()> pos)  {
			Combo elcombo = combos.get(pos);
			String nombre = elcombo.darNombre();
			if (nombre.equals(nomcombo)){
				String hambur = elcombo.darHamburguesa();
				
				String papa = elcombo.darPapas();
				String gas = elcombo.darGaseosa();
				sigue = false;
				int posicion = 0;
				boolean seguir = true;
				while ( menu.size()> posicion && seguir == true) {
					Menu ingre = (Menu) menu.get(posicion);
					String ingres = ingre.getNombre();
					if (ingres.equals(papa)) {
						double prec = ingre.getPrecio();
						
						respuesta = respuesta +  (prec-prec*desc);
						seguir = false;
						
						
								
					}
				
					posicion = posicion +1;
				}
				posicion = 0;
				seguir = true;
				while ( menu.size()> posicion && seguir == true) {
					Menu ingre = (Menu) menu.get(posicion);
					String ingres = ingre.getNombre();
					if (ingres.equals(gas)) {
						double prec = ingre.getPrecio();
						
						respuesta = respuesta +  (prec-prec*desc);;
						seguir = false;
						
								
					}
				
					posicion = posicion +1;
				}
				posicion = 0;
				seguir = true;
				while ( menu.size()> posicion && seguir == true) {
					Menu ingre = (Menu) menu.get(posicion);
					String ingres = ingre.getNombre();
					if (ingres.equals(hambur)) {
						double prec = ingre.getPrecio();
						
						respuesta = respuesta +  (prec-prec*desc);
						
						seguir = false;
								
					}
				
					posicion = posicion +1;
				}
				
				
				
				
						
				
						
			}
			pos = pos + 1;
					
		}
		return respuesta;
		
	}
	public  Combo pedidocombo(int pos) {
		Combo respuesta = combos.get(pos);
		
		
		return respuesta;
		
		
	}
	public  String pedidproductonom(int pos) {
		Menu respuesta = (Menu) menu.get(pos);
		String nom = respuesta.getNombre();
		
		return nom;
	}
	public  Double pedidproductopre(int pos) {
		Menu respuesta = (Menu) menu.get(pos);
		Double nom = respuesta.getPrecio();
		
		return nom;
	}
	public  Double pedidoingrepre(int pos) {
		Ingredientes respuesta = (Ingredientes) ingredientes.get(pos);
		Double nom = respuesta.getPrecio();
		
		return nom;
	}
	public  String pedidoingreonom(int pos) {
		Ingredientes respuesta = (Ingredientes) ingredientes.get(pos);
		String nom = respuesta.getNombre();
		
		return nom;
	}
	public void pedido(Integer orden, Pedidos pedido) {
		pedidos.put(orden, pedido);
		
	}	
	public Pedidos buscarped(Integer id) {
		Pedidos actual = pedidos.get(id);
		
		
		return actual;
		
	}
	public boolean VerificarPrecio(double pre) throws Exception{
		if (pre>= 150000) {
			throw new Exception("El producto supero 150,000");
		}return true;
	}
}


	