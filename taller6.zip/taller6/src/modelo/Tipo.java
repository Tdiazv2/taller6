package modelo;

public abstract class Tipo {
	public String nombre;
	public Double precio;
	
	public Tipo (String nombre, Double precio ) {
		super();
		this.nombre = nombre;
		this.precio = precio;
	}

	public  abstract String getNombre();

	public abstract void setNombre(String nombre);

	public abstract  Double getPrecio();

	public abstract void setPrecio(Double precio);
	
}
