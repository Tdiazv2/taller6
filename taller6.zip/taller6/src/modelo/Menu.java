package modelo;

public class Menu extends Tipo {
	public Menu(String elNombre, Double elprecio) {
		super(elNombre, elprecio);
		// TODO Auto-generated constructor stub
	}

	
	
	
	@Override
	public String getNombre() {
		// TODO Auto-generated method stub
		return this.nombre;
	}
	@Override
	public void setNombre(String nombre) {
		// TODO Auto-generated method stub
		this.nombre= nombre;
	}
	@Override
	public Double getPrecio() {
		// TODO Auto-generated method stub
		return this.precio;
	}
	@Override
	public void setPrecio(Double precio) {
		// TODO Auto-generated method stub
		this.precio = precio;
	}
	
}
