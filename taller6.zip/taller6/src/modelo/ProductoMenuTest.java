package modelo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controlador.Restaurante;
import controlador.carga;

class ProductoMenuTest {
	private Restaurante res;
	@BeforeEach
	public void setUp() throws Exception {
		res = carga.Leer("data/combos.txt", "data/menu.txt", "data/ingredientes.txt");
	}
	@Test
	void test() {
		fail("Not yet implemented");
	}

}
