package modelo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controlador.Restaurante;
import controlador.carga;

class PedidoTest {
	private Restaurante res;
	@BeforeEach
	public void setUp() throws Exception {
		res = carga.Leer("data/combos.txt", "data/menu.txt", "data/ingredientes.txt");
	}
	@Test
	public void PedirMenutest() {
		
		assertEquals(22000.0, res.pedidproductopre(0),"Se eligio correcto el producto");
	}

}
